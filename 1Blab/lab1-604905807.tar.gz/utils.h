#ifndef UTILS_H
#define UTILS_H

int stoi(char* string);
int max(int a, int b);

#endif
