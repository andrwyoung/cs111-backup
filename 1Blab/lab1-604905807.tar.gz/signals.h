#ifndef SIGNALS_H
#define SIGNALS_H

void aborter();
void catcher();

#endif
