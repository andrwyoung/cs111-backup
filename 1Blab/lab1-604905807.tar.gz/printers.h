#ifndef PRINTERS_H
#define PRINTERS_H

void errmess();
void stringer0(char option[]);
void stringer1(const char option[], const char arguments[]);
void stringer2(char** cmd, int args);
int stoi(char* string);

#endif
