//NAME: Andrew Yong
//EMAIL: yong.andrew11@gmail.com
//ID: 604905807

#ifndef CONVERTER_H
#define CONVERTER_H

void reverse(char *str, int len);
int intToStr(int x, char str[], int d);
void ftoa(float n, char *res, int afterpoint);

#endif
